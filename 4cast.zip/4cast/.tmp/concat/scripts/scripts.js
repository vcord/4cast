'use strict';
/**
* APP NAME: MYGEO
* @author vcord ukandu michael <vcordukandu@gmail.com>
* @url https://github.com/vcord/mygeo
* @desc A simple application for readin user's current weather condition and also useful for general weather forecast. This           * application stores forecast history in the local storage.
*/
angular
  .module('4castApp', [
    'ngAnimate',
    'ngAria',
    'ngCookies',
    'ngResource',
    'ui.router', 
    'ngSanitize',
    'ngTouch',
	'angular-loading-bar',
	'angularMoment',
	'toastr',
	'ui.bootstrap'
  ])
  .config(["$stateProvider", "$urlRouterProvider", "$locationProvider", "cfpLoadingBarProvider", function ($stateProvider, $urlRouterProvider, $locationProvider, cfpLoadingBarProvider) {
	  $locationProvider.html5Mode(true);
	  $stateProvider
		.state('home', {
		url : '/',
		controller:'GeoCtrl',
		templateUrl: 'views/main.html'
		});
		$urlRouterProvider.otherwise("/");
		
		 cfpLoadingBarProvider.includeSpinner = true;
         cfpLoadingBarProvider.includeBar = true;
  }])
  
  .run(["$rootScope", function($rootScope) {
    $rootScope.API = {
		google:{
            key:'AIzaSyBKk8Dtb_C-fwCH9A61Fp_utGCHPx-reFA',
            url:'https://maps.googleapis.com/maps/api/geocode/json',
        },
		
		openweather: {
            key:'93be51540090e5825beb7296aa0b1394',
            url:'http://api.openweathermap.org/data/2.5/weather'
        }
	};
	
	
}]);

'use strict';

/**
 * @ngdoc service
 * @name 4castApp.findme
 * @description
 * # findme
 * Service in the 4castApp.
 */
angular.module('4castApp')
  .service('findme', ["$log", "$http", "$q", "$window", "$timeout", function ($log, $http, $q, $window, $timeout) {
   
   var locator={};
   
   locator.now = function()
             {
                 var deferred;
                 
                 var promiseTimeout = $timeout(function() {
                     deferred.reject(1); // return 1 if browser waited for user input for more than timeout delay
                    }, 5000);
                 
						deferred = $q.defer();
                 
                 // check if geoLocation is not supported by browser
                 if(!$window.navigator.geolocation) { 
                        $timeout.cancel(promiseTimeout);
                     
                     // return false if geoLocation is not supported
                        deferred.reject(false); 
                     
                    }else{
                     
                     //Fires the HTML5 Geolocation API
                     $window.navigator.geolocation.getCurrentPosition(
                         
                    //resolves the geolocation response.
                    function(position) {
                        $timeout.cancel(promiseTimeout);
                        return deferred.resolve(position);
                    }, 
                    
                    //Resolves the Geolocation Error.
                    function(error) {
                        $timeout.cancel(promiseTimeout);
                        return deferred.reject(error.code || 1);
                    },
                      
                    //sets the HTML5 geolocation optional features.
                      {
                     enableHighAccuracy : true,
                        timeout : Infinity,
                        maximumAge : 0
                     }
                                                                      
                    );
                 }
                 
                 return deferred.promise;
             };
			 
			 return locator;
   
  }]);

'use strict';

/**
* @implements a simple local storage database.
* stores data in JSON format, immitating a real database.
*/
angular.module('4castApp')
  .service('vcordDB', ["$window", function ($window) {
	  
	var DB = {};
	
	/**
        * @obj DB.table - creates the database table.
        * In actual sense, the local storage Key and sets an empty array as its value.
        */
             
         DB.table = function(table)
         {
             if(!$window.localStorage.getItem(table))
                 {
                    var setDb = {"db":[]};
                    var dbObj = JSON.stringify(setDb);
                    return  $window.localStorage.setItem(table, dbObj);
                     
                 }else{
                     
                     return false;
                 }
              
         };
		 
		 
		 /**
         * Implements the save Feature.
         * saves a new data in the localstorage array.
         * @param table - the table name
         * @param data - the new table value.
         */
         
         DB.Insert = function(table, data)
         {   
              var old_storage = $window.localStorage.getItem(table);
               var trans = JSON.parse(old_storage);
                var newItem = trans["db"].push(data);
                var filt = JSON.stringify(trans);
               $window.localStorage.setItem(table, filt);
             
         };
		 
		 /**
         * Implements the get feature
         * @returns all datas stored to a provided key; returns false if no table is found.
         */
         
         DB.FetchAll = function(table)
         {
             var storage = $window.localStorage.getItem(table);
             
             if(!storage)
                 {
                     return false;
                 }else{
                     var transform = JSON.parse(storage);
                     var arr = transform["db"];

                    return arr;
                 }
         };
         
         /**
         * returns the count of all stored data.
         */
         
         DB.Count = function(table)
         {
            var storage = $window.localStorage.getItem(table);
             
             if(!storage)
                 {
                     return false;
                 }else{
                     
                     var transformData = JSON.parse(storage);
                     var count = transformData.db.length;
                     
                     return count;
                 }
         };
         
         
         /**
         * Implements the delete functionality
         * deletes all data for a given table (key)
         */
         
         DB.DeleteAll = function(table)
         {
             var storage = $window.localStorage.getItem(table);
             
             if(!storage)
                 {
                     return false;
                 }else{
                     
                     var setDb = {"db":[]};
                    var dbObj = JSON.stringify(setDb);
                     
                     $window.localStorage.setItem(table, dbObj);
                 }
         };
		 
		 
		 return DB;
	
  }]);

'use strict';

/**
* @Implements Geo controller
*/
angular.module('4castApp')
.controller('GeoCtrl', ["$scope", "$http", "toastr", "$window", "$state", "findme", "$rootScope", "vcordDB", function ($scope, $http, toastr, $window, $state, findme, $rootScope, vcordDB) {

			//gets all weather forecast history from the Local storage.
			$scope.LoadWeather = vcordDB.FetchAll('myGeo');
			
			//gets the total count of weather forecast history from the Local storage.
			$scope.WeatherCount = vcordDB.Count('myGeo');

			/**
			* Uses the Html5 geolocation api to fetch user's current weather from
			* openwaether API and broadcast's the showWeather event.
			*/
			$scope.getLocation = function(){

			findme.now().then(function(position){
			var data = position.coords;


			//checks if is there has been a forecast made with this device.
			if(vcordDB.Count('myGeo') < 0 || !vcordDB.Count('myGeo')) 
			{
			// if not, trigger the show weather event. and use the openweather API to fetch current weather,
			// and broadcast the ShowWeather event.
			$http.jsonp($rootScope.API.openweather.url, {params:{lat: data.latitude, lon: data.longitude, appid:$rootScope.API.openweather.key, callback: 'JSON_CALLBACK'}})
			.then(function(response){
			$scope.$broadcast('ShowWeather', response.data);
			});

			}else{

			//if there has been a forecast, trigger a warning, asking the user to check waether manually.
			toastr.warning('Oops!! you already have a History, Please check your weather manually!');
			}

			},function(err){

			//checks if the browser supports HTML5 geolocation API.
			if(err === false)

			{
			toastr.warning('Your browser does not support Html5 Geolocation API');
			}

			/**
			* check if the user rejects the HTML5 geolocation API.
			*/

			if(err === 1)
			{
			//if there has been a forecast, trigger a warning, asking the user to check waether manually.
			if(vcordDB.Count('myGeo') < 0 || !vcordDB.Count('myGeo'))
			{
			//if not, triggers the UserReject event
			return $scope.$broadcast('UserReject', 'rejected'); 
			}else{

			toastr.warning('Oops!! you already have a History, Please check your weather manually!');
			}
			}

			if(err === 2)//checks if HTML5 geolocation API is available, probably due to bad internet connection.

			{
			toastr.warning('Your current position is not available. Please check your internet connection.');
			}

			});

			};


			/**
			* listens to the saveWeather event
			* and saves the weather Data to the localstorage in Json Format and reloads the browser.
			*/
			$scope.SaveWeather = function()
			{
			$scope.$on('saveWeather', function(evt, data){
			vcordDB.table('myGeo');

			var fields = {
			ref_id: $scope.uniqeId(10),
			location: data.name,
			weather:$scope.ToCelcius(data.main.temp),
			wind:$scope.ToKilometer(data.wind.speed),
			humidity: data.main.humidity,
			description: data.weather[0].description,
			date: new Date()
			};

			vcordDB.Insert('myGeo', fields);
			$window.location.reload();
			});
			};

			//clears all weather history
			$scope.clearHistory = function()
			{
			vcordDB.DeleteAll('myGeo');

			$window.location.reload();

			};

			//scope to for implementing the Kelvin to Celsius method.
			$scope.ToCelcius = function(val)
			{
			var result = val - 273.15;
			var appr = Math.round(result);
			return appr;
			};

			//scope to for implementing the Meter to Kilometer method.
			$scope.ToKilometer = function(val)
			{
			var result = val * 3.60;
			var approx = Math.round(result * 100)/100;
			return approx;
			};


			//method for generating a unique string. used for the RefId
			$scope.uniqeId = function randomstring(L)
			{
			var s= '';
			var randomchar=function(){
			var n= Math.floor(Math.random()*62);
			if(n<10)
				return n; //1-10
			if(n<36)
				return String.fromCharCode(n+55); //A-Z
				return String.fromCharCode(n+61); //a-z
			
			};
			while(s.length< L)
				s+= randomchar();
				return s;
			
			};


			$scope.SaveWeather();

}]);

'use strict';

/**
* The GeoFormCtrl
* Handles modal form related features.
*/

angular.module('4castApp')
.controller('GeoformCtrl', ["$scope", "$rootScope", "$http", function ($scope, $rootScope, $http) {

		$scope.formGeoLocate = {};

		/**
		* Auto suggests placea, address, zipcode on input.
		* fetches Data from google map api.
		*/

		$scope.getLocation = function(val) {
		return $http.get($rootScope.API.google.url, {
		params: {
		address: val,
		sensor: false,
		key: $rootScope.API.google.key
		}
		}).then(function(response){
		return response.data.results.map(function(item){
		$scope.formGeoLocate = item.geometry.location;
		return item.formatted_address;
		});
		});
		};


		/**
		* fetches the current weatheer from the openWeather API and 
		* emits the showWeather event to pass the response around.
		*/

		$scope.showWeather = function(data)
		{
		$http.jsonp($rootScope.API.openweather.url, {params:{lat: data.lat, lon: data.lng, appid:$rootScope.API.openweather.key, callback: 'JSON_CALLBACK'}})
		.then(function(response){
		$scope.$emit('ShowWeather', response.data);
		});

		};

}]);

'use strict';


/**
* The ModalCtrl
* Implements the bootstrap modal.
*/
angular.module('4castApp')
.controller('ModalCtrl', ["$scope", "$uibModal", "$document", "$rootScope", function ($scope, $uibModal, $document, $rootScope) {

			/**
			* implements the country search and place modal<pop up>
			* listens to the UserReject event and pops up.
			*/

			$scope.showReject = function()
			{
			$scope.$on("UserReject", function(evt,data){
			var modalInstance = $uibModal.open({
			backdrop:'static',
			templateUrl: 'views/partials/modal_home.html',
			size: 'sm',
			controller: 'ModalinstanceCtrl',

			});
			});
			};


			/**
			* implements the normal country search modal.
			*/

			$scope.showManual = function()
			{
			var modalInstance = $uibModal.open({
			templateUrl: 'views/partials/modal_home.html',
			size: 'sm',
			controller: 'ModalinstanceCtrl',

			});
			};

			/**
			* implements the recent weather modal.
			* listens to the showWeather event.
			*/

			$scope.showWeatherForm = function()
			{
			$scope.$on("ShowWeather", function(evt,data){
			$rootScope.weatherData = data;
			var modalInstance = $uibModal.open({
			backdrop:'static',
			templateUrl: 'views/partials/modal_weather.html',
			size: 'sm',
			controller: 'ModalinstanceCtrl',
			});

			});

			};

			$scope.showReject();
			$scope.showWeatherForm();
}]);

'use strict';

/**
* implements the modal instance controller.
* responsible for closing the modal.
*/
angular.module('4castApp')
.controller('ModalinstanceCtrl', ["$scope", "$rootScope", "$uibModalInstance", function ($scope, $rootScope, $uibModalInstance) {

			/**
			* closes the show weather modal broadcasting the saveWeather event.
			*/
			$scope.saveWeather = function (data) {
			$scope.$broadcast('saveWeather', data);
			$uibModalInstance.close();
			};

			/**
			* a re-usable method for closing any modal
			*/
			$scope.close = function()
			{
			$uibModalInstance.close();
			};


			/**
			* a re-usable method for cancelling any modal
			*/

			$scope.cancel = function () {
			$uibModalInstance.dismiss('cancel');
			};

}]);

angular.module('4castApp').run(['$templateCache', function($templateCache) {
  'use strict';

  $templateCache.put('views/about.html',
    "<p>This is the about view.</p>"
  );


  $templateCache.put('views/main.html',
    "<div class=\"container\" ng-controller=\"GeoCtrl\"> <div ng-controller=\"ModalCtrl\"></div> <div class=\"row\"> <div class=\"col-xs-12\" ng-init=\"getLocation()\"> <div class=\"panel panel-default\"> <div class=\"panel-heading app-panel\">Forecast History <button class=\"btn btn-red btn-circle pull-right\" ng-click=\"clearHistory()\">Clear History</button></div> <div class=\"list-group\" ng-repeat=\"info in LoadWeather\"> <div class=\"list-group-item weather-bag\" style=\"overflow:hidden\"> <div class=\"col-xs-6\"> <h3>{{info.location}} <span class=\"badge badge-mine\">Ref ID: {{info.ref_id}}</span></h3> <h4>{{info.description}}</h4> <p class=\"meta info\">{{info.weather}}&deg;<span>C</span></p> </div> <div class=\"col-xs-6\"> <div class=\"sub-meta pull-right\"> <h4>Humidity: {{info.humidity}}%</h4> <h4>Wind: {{info.wind}}km/h</h4> <h4 am-time-ago=\"info.date\"></h4> </div> </div> </div> </div> </div> </div> </div> </div>"
  );


  $templateCache.put('views/partials/modal_home.html',
    "<div ng-controller=\"ModalCtrl\"> <div class=\"modal-header\"> <h5 class=\"modal-title text-center text-muted\" id=\"modal-title\">Please Provide Your Zip Code or City Name For Weather Forecast:</h5> </div> <div ng-controller=\"GeoformCtrl\"> <div class=\"modal-body text-center\" id=\"modal-body\"> <input type=\"text\" ng-model=\"asyncSelected\" placeholder=\"Enter Your City,country,zip code etc\" uib-typeahead=\"address for address in getLocation($viewValue)\" typeahead-loading=\"loadingLocations\" typeahead-no-results=\"noResults\" class=\"form-control\"> <i ng-show=\"loadingLocations\" class=\"glyphicon glyphicon-refresh\"></i> <div ng-show=\"noResults\"> <i class=\"glyphicon glyphicon-remove\"></i> No Results Found </div> </div> <div class=\"modal-footer\"> <button class=\"btn btn-circle btn-green\" type=\"button\" ng-click=\"showWeather(formGeoLocate)\">Show Weather</button> </div> </div> </div>"
  );


  $templateCache.put('views/partials/modal_weather.html',
    "<div ng-controller=\"ModalCtrl\"> <div ng-controller=\"GeoCtrl\"> <div class=\"modal-header\"> <h3 class=\"modal-title text-center\" id=\"modal-title\">{{weatherData.name}} Current Weather</h3> </div> <div class=\"modal-body\" id=\"modal-body\"> <div class=\"weather-bag\" style=\"overflow:hidden\"> <h3>{{weatherData.name}}</h3> <h4>{{weatherData.weather[0].description}}</h4> <img src=\"views/img/therm.svg\" class=\"img-responsive info\" width=\"70\"> <p class=\"meta info\">{{ToCelcius(weatherData.main.temp)}}º<span>C</span></p> <div class=\"sub-meta pull-right\"> <h4>Humidity: {{weatherData.main.humidity}}%</h4> <h4>Wind: {{ToKilometer(weatherData.wind.speed)}}km/h</h4> </div> </div> </div> <div class=\"modal-footer\"> <button class=\"btn btn-circle btn-green\" type=\"button\" ng-click=\"saveWeather(weatherData)\">Save &amp; Close</button> </div> </div> </div>"
  );

}]);
