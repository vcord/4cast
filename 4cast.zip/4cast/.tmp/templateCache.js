angular.module('4castApp').run(['$templateCache', function($templateCache) {
  'use strict';

  $templateCache.put('views/about.html',
    "<p>This is the about view.</p>"
  );


  $templateCache.put('views/main.html',
    "<div class=\"container\" ng-controller=\"GeoCtrl\"> <div ng-controller=\"ModalCtrl\"></div> <div class=\"row\"> <div class=\"col-xs-12\" ng-init=\"getLocation()\"> <div class=\"panel panel-default\"> <div class=\"panel-heading app-panel\">Forecast History <button class=\"btn btn-red btn-circle pull-right\" ng-click=\"clearHistory()\">Clear History</button></div> <div class=\"list-group\" ng-repeat=\"info in LoadWeather\"> <div class=\"list-group-item weather-bag\" style=\"overflow:hidden\"> <div class=\"col-xs-6\"> <h3>{{info.location}} <span class=\"badge badge-mine\">Ref ID: {{info.ref_id}}</span></h3> <h4>{{info.description}}</h4> <p class=\"meta info\">{{info.weather}}&deg;<span>C</span></p> </div> <div class=\"col-xs-6\"> <div class=\"sub-meta pull-right\"> <h4>Humidity: {{info.humidity}}%</h4> <h4>Wind: {{info.wind}}km/h</h4> <h4 am-time-ago=\"info.date\"></h4> </div> </div> </div> </div> </div> </div> </div> </div>"
  );


  $templateCache.put('views/partials/modal_home.html',
    "<div ng-controller=\"ModalCtrl\"> <div class=\"modal-header\"> <h5 class=\"modal-title text-center text-muted\" id=\"modal-title\">Please Provide Your Zip Code or City Name For Weather Forecast:</h5> </div> <div ng-controller=\"GeoformCtrl\"> <div class=\"modal-body text-center\" id=\"modal-body\"> <input type=\"text\" ng-model=\"asyncSelected\" placeholder=\"Enter Your City,country,zip code etc\" uib-typeahead=\"address for address in getLocation($viewValue)\" typeahead-loading=\"loadingLocations\" typeahead-no-results=\"noResults\" class=\"form-control\"> <i ng-show=\"loadingLocations\" class=\"glyphicon glyphicon-refresh\"></i> <div ng-show=\"noResults\"> <i class=\"glyphicon glyphicon-remove\"></i> No Results Found </div> </div> <div class=\"modal-footer\"> <button class=\"btn btn-circle btn-green\" type=\"button\" ng-click=\"showWeather(formGeoLocate)\">Show Weather</button> </div> </div> </div>"
  );


  $templateCache.put('views/partials/modal_weather.html',
    "<div ng-controller=\"ModalCtrl\"> <div ng-controller=\"GeoCtrl\"> <div class=\"modal-header\"> <h3 class=\"modal-title text-center\" id=\"modal-title\">{{weatherData.name}} Current Weather</h3> </div> <div class=\"modal-body\" id=\"modal-body\"> <div class=\"weather-bag\" style=\"overflow:hidden\"> <h3>{{weatherData.name}}</h3> <h4>{{weatherData.weather[0].description}}</h4> <img src=\"views/img/therm.svg\" class=\"img-responsive info\" width=\"70\"> <p class=\"meta info\">{{ToCelcius(weatherData.main.temp)}}º<span>C</span></p> <div class=\"sub-meta pull-right\"> <h4>Humidity: {{weatherData.main.humidity}}%</h4> <h4>Wind: {{ToKilometer(weatherData.wind.speed)}}km/h</h4> </div> </div> </div> <div class=\"modal-footer\"> <button class=\"btn btn-circle btn-green\" type=\"button\" ng-click=\"saveWeather(weatherData)\">Save &amp; Close</button> </div> </div> </div>"
  );

}]);
